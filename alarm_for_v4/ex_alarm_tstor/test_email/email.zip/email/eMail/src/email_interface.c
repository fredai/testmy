/*
 *
 * email_interface.c
 *
 */

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/wait.h>

#include "email.h"

#define EMAIL_TIMEOUT 60*3

FILE * g_stdout;
FILE * g_stderr;


void timeout ( int signum ) {
    fprintf ( g_stderr, "time out %d with signal %d\n", EMAIL_TIMEOUT, signum );
    exit ( 7 );
}

int send_email ( email_config_t * email_config, char * subject, char * content, \
        char * error_msg, int error_msg_len ) {
    if ( email_config == NULL || subject == NULL || content == NULL || \
            error_msg == NULL || error_msg_len < 2 ) {
        return -1;
    }
    int ret;
    pid_t fork_result;
    int pipefd [ 2 ];
    char buffer [ BUFSIZ + 8 ];
    int data_len = 0;
    int stat_val;

    ret = pipe ( pipefd );
    if ( ret == -1 ) {
        return -2;
    }

    fork_result = fork ( );
    if ( fork_result == -1 ) {
        return -3;
    }
    else if ( fork_result > 0 ) {
        close ( pipefd [ 1 ] );
        data_len = 0;
        int have_read = 0;
        while ( 1 ) {
            data_len = read ( pipefd [ 0 ], buffer + have_read, BUFSIZ - have_read );
            if ( data_len == 0 || have_read >= BUFSIZ ) {
                break;
            }
            have_read += data_len;
        }
        close ( pipefd [ 0 ] );
        waitpid ( fork_result, & stat_val, 0 );
        if ( have_read == 0 ) {
            return 0;
        }
        else {
            int str_len = have_read < error_msg_len ? have_read : error_msg_len - 1;
            strncpy ( error_msg, buffer, str_len );
            if ( error_msg [ str_len - 1 ] == '\n' ) {
                str_len --;
            }
            error_msg [ str_len ] = '\0';
            return -4;
        }
    }
    else {
        /*dup2 ( pipefd [ 1 ], 1 );
        dup2 ( pipefd [ 1 ], 2 );
        close ( pipefd [ 1 ] );*/
        close ( pipefd [ 0 ] );
        g_stderr = fdopen ( pipefd [ 1 ], "w" );
        if ( g_stderr == NULL ) {
            exit ( 5 );
        }
        g_stdout = fopen ( "/dev/null", "w" );
        if ( g_stdout == NULL ) {
            exit ( 6 );
        }
        struct sigaction act;
        act.sa_handler = timeout;
        sigemptyset ( & act.sa_mask );
        act.sa_flags = 0;
        sigaction ( SIGALRM, & act, 0 );
        alarm ( EMAIL_TIMEOUT );

        //fprintf ( g_stderr, "%s", "hello aaaaaaaaaaa" );
        //write ( pipefd [ 1 ], "hello", 6 );
        dj_email ( email_config, subject, content );
        fprintf ( g_stderr, "unknown error" );
        exit ( 8 );
    }
    return -9;
}


/*end of file*/

